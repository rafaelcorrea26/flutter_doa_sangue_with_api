package com.example.doa_sangue

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
