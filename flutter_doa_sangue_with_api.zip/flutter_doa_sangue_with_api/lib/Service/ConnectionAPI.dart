import 'package:doa_sangue/Utils/UserSecureStorage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../Model/Usuario.dart';


//const urlAPI = "http://locahost:8000/api/";
//const urlAPI = "http://192.168.10.22:8000/api/";

class ConnectionAPI{
  static const urlAPI = "http://10.0.2.2:8001/api/";

  static Future<bool> Login(email , senha) async {

    var url = Uri.parse(urlAPI + 'login');
    url = url.replace(queryParameters: {'email': email, 'senha': senha});
    print(url);

    var response = await http.post(url, headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    });

    if (response.statusCode == 200) {
      print(response.body);
      print(json.decode(response.body)["token"]);
      print(json.decode(response.body)["usuario"]);

      Usuario usuario = Usuario();
      UserSecureStorage.setToken(json.decode(response.body)["token"]) ;
      usuario =  Usuario.fromMap(json.decode(response.body)["usuario"]);
      UserSecureStorage.setUsuario(usuario.toString()) ;
      return true;
    } else {
      return false;
    }
  }

}