import 'dart:io';
import 'dart:convert';
import 'ConnectionAPI.dart';
import '../Model/Agendamento.dart';
import 'package:http/http.dart' as http;
import 'package:doa_sangue/Utils/UserSecureStorage.dart';

class AgendamentoRest {
  Agendamento _agendamento = Agendamento();
  String? _token;
  var _url = Uri.parse(ConnectionAPI.urlAPI + 'agendamento');
// GET
  Future<Agendamento> getAgendamento(int id) async {
    var _urlID =  Uri.parse(ConnectionAPI.urlAPI + 'agendamento/' +id.toString());
    _token = await UserSecureStorage.getToken();

    if ((_token == '') | (_token == null)) { // Valida se nao existe o token na memoria
      exit(0);// fecha o app
    }

    final _response = await http.get(_urlID, headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer $_token',
    });
    print(_response.statusCode);
    print(_response.body);


    if ((_response.statusCode == 200) & (json.decode(_response.body)["agendamento"] != '[]')) {
      _agendamento =  Agendamento.fromMap(json.decode(_response.body)["agendamento"]);
      print(_response.body);
    }
    return _agendamento;
  }


  Future<List<Agendamento>> getAllAgendamento() async {
    List<Agendamento> agendamento = [];
    _token = await UserSecureStorage.getToken();

    if ((_token == '') | (_token == null)) { // Valida se nao existe o token na memoria
      exit(0);// fecha o app
    }

    final _response = await http.get(_url, headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer $_token',
    });

    if ((_response.statusCode == 200) & (json.decode(_response.body)["agendamento"] != '[]')) {
     List<dynamic> _list = jsonDecode(_response.body)["agendamento"] ;
     print(_list);
     agendamento = _list.map((json) => Agendamento.fromJson(json)).toList();
  }
      return agendamento;
    }

// POST
  Future<int> postAgendamento(Agendamento agendamento) async {
    try {
      if ((_token == '') | (_token == null)) {
        exit(0); // fecha o app
      }
      var _resposta = await http.post(_url, headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': 'Bearer $_token',
      } , body: agendamento.toJson());

      print(_resposta.statusCode);
      print(_resposta.body);

      if (_resposta.statusCode == 201) {
        print(_resposta.body);

        return  json.decode(_resposta.body)["id"];
      } else {
        return 0;
      }

    } catch (ex) {
      print(ex);
      return 0;
    }
  }

// PUT
  Future<String> putAgendamento(Agendamento agendamento) async {
    var _urlID =  Uri.parse(ConnectionAPI.urlAPI + 'agendamento/' +agendamento.id.toString());
    try {

      if ((_token == '') | (_token == null)) {
        exit(0); // fecha o app
      }
      var _resposta = await http.put(_urlID, headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': 'Bearer $_token',
      } , body: agendamento.toJson());

      print(_resposta.statusCode);
      print(_resposta.body);

      if (_resposta.statusCode == 200) {
        print(_resposta.body);
        return "Agendamento Alterado!";
      } else {
        return "Agendamento não Alterado!";
      }
    } catch (ex) {
      print(ex);
      return "Agendamento não Alterado!";
    }
  }

//DELETE
  Future<String> deleteAgendamento(int id) async {

    var _urlID =  Uri.parse(ConnectionAPI.urlAPI + 'agendamento/' +id.toString());
    try {

      if ((_token == '') | (_token == null)) {
        exit(0); // fecha o app
      }
      var _resposta = await http.put(_urlID, headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': 'Bearer $_token',
      } );

      print(_resposta.statusCode);
      print(_resposta.body);

      if (_resposta.statusCode == 200) {
        print(_resposta.body);
        return "Agendamento Deletado!";
      } else {
        return "Agendamento não Deletado!";
      }
    } catch (ex) {
      print(ex);
      return "Agendamento não Deletado!";
    }
  }
}