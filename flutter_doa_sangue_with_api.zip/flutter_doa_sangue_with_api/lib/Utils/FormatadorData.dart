String? ConverteDataParaDataAPI(String pDataPT){
var dataold;
var data;

dataold = pDataPT;
data =(dataold.substring( 6,10));
data = (data +'-'+ dataold.substring(3,5));
data = data +'-'+ dataold.substring(0,2);

return data;
}
